var struct_l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e =
[
    [ "busy", "struct_l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e.html#abbe792bb2cf67584b86443440a194f46", null ],
    [ "callback", "struct_l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e.html#ad1e465b5eaf735d9cda63e5ee7842bcd", null ],
    [ "LEUARTn", "struct_l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e.html#a8aecfbce5b5d54d2bc7f00891e039dd8", null ],
    [ "sent_bytes", "struct_l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e.html#ab59122e8a08b1d0501190652369cded9", null ],
    [ "state", "struct_l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e.html#a1b0c7bd4d79798ef4e0ce23894c9aeb2", null ],
    [ "str", "struct_l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e.html#ab50d783982593ef993ea0b68f7ad8b80", null ],
    [ "str_len", "struct_l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e.html#ac0a18a0c6eb970717f90b8ae63c033a7", null ]
];