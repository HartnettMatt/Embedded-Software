var _si7021_8c =
[
    [ "si7021_i2c_open", "_si7021_8c.html#a862dd7e8aee832b32edc73ce19f19158", null ],
    [ "si7021_i2c_read", "_si7021_8c.html#ab60c01ffc6fe96d40b205b5e137226d2", null ],
    [ "si7021_temp", "_si7021_8c.html#a23949513214853d32cda8a8cb2225dc5", null ]
];