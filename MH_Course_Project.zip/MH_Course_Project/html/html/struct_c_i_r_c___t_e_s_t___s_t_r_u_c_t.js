var struct_c_i_r_c___t_e_s_t___s_t_r_u_c_t =
[
    [ "result_str", "struct_c_i_r_c___t_e_s_t___s_t_r_u_c_t.html#a2592a54d3a8f67941ed5245b47f94fe2", null ],
    [ "test_str", "struct_c_i_r_c___t_e_s_t___s_t_r_u_c_t.html#a1f84123036c552f6ecb4e84ce7f7886e", null ]
];