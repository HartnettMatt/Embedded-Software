var searchData=
[
  ['i2c_5fopen_5fstruct_76',['I2C_OPEN_STRUCT',['../struct_i2_c___o_p_e_n___s_t_r_u_c_t.html',1,'']]],
  ['i2c_5fstate_5fmachine_77',['I2C_STATE_MACHINE',['../struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html',1,'']]]
];
