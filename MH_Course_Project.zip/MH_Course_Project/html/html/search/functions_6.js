var searchData=
[
  ['remove_5fscheduled_5fevent_130',['remove_scheduled_event',['../scheduler_8c.html#a89d9fd534ca49cadaeebe2048f2f6294',1,'scheduler.c']]],
  ['rx_5fstr_131',['rx_str',['../leuart_8c.html#aac420e14c60351764730de15914207b1',1,'leuart.c']]]
];
