var searchData=
[
  ['update_5fcirc_5freadtindex_71',['update_circ_readtindex',['../ble_8c.html#a190b384d74b6a4ab3e069b12de1fe86f',1,'ble.c']]],
  ['update_5fcirc_5fwrtindex_72',['update_circ_wrtindex',['../ble_8c.html#ae059df3ee946d09f3c849b2d38a90ab3',1,'ble.c']]]
];
