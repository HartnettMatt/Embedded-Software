var struct_t_x___l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e =
[
    [ "busy", "struct_t_x___l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e.html#abbe792bb2cf67584b86443440a194f46", null ],
    [ "callback", "struct_t_x___l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e.html#ad1e465b5eaf735d9cda63e5ee7842bcd", null ],
    [ "LEUARTn", "struct_t_x___l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e.html#a8aecfbce5b5d54d2bc7f00891e039dd8", null ],
    [ "sent_bytes", "struct_t_x___l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e.html#ab59122e8a08b1d0501190652369cded9", null ],
    [ "state", "struct_t_x___l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e.html#a1b0c7bd4d79798ef4e0ce23894c9aeb2", null ],
    [ "str", "struct_t_x___l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e.html#afd6eea465afb994c07f7abe493aa01ab", null ],
    [ "str_len", "struct_t_x___l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e.html#ac0a18a0c6eb970717f90b8ae63c033a7", null ]
];