var scheduler_8c =
[
    [ "add_scheduled_event", "scheduler_8c.html#a4656e4fa005f4bef2f132423f1fc08c8", null ],
    [ "get_scheduled_events", "scheduler_8c.html#a78f831851a72a952fa57b5528ebd5536", null ],
    [ "remove_scheduled_event", "scheduler_8c.html#a89d9fd534ca49cadaeebe2048f2f6294", null ],
    [ "scheduler_open", "scheduler_8c.html#afbc09e3ce15ae2e0f91802ec1a8d2549", null ]
];