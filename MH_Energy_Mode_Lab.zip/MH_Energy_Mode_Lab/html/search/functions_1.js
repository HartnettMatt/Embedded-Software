var searchData=
[
  ['cmu_5fopen_27',['cmu_open',['../cmu_8c.html#a0bf9288af36bde6e21cc7c79382fff11',1,'cmu.c']]]
];
