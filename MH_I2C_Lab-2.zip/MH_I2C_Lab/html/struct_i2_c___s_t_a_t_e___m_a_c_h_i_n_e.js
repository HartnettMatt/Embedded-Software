var struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e =
[
    [ "callback", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html#ad1e465b5eaf735d9cda63e5ee7842bcd", null ],
    [ "command", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html#af7e471411e95448316f756e3905fdcce", null ],
    [ "data", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html#aa1cf91039f621340f15bcd4c95f582ef", null ],
    [ "I2Cn", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html#ae1d34d97f1ebae0965d2b6b1a3a42d8d", null ],
    [ "read", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html#af49a80be54293d8b153cd2a3dfd4e068", null ],
    [ "slave_address", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html#a1625d58245976f4795b44bcde619ce3a", null ],
    [ "state", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html#a1b0c7bd4d79798ef4e0ce23894c9aeb2", null ]
];