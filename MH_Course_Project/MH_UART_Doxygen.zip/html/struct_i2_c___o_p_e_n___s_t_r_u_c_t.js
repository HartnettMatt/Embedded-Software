var struct_i2_c___o_p_e_n___s_t_r_u_c_t =
[
    [ "clhr", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a21fe116060fe1e7dcefef7e0114b18bd", null ],
    [ "enable", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#ac842b6c1dcb3b1f11b611620199dc55c", null ],
    [ "event_def", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a8e768d0745e6e5fdc2fed5e146af86ab", null ],
    [ "freq", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#aacfad457f5366fa9265eb0a89e43f23b", null ],
    [ "master", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a076a973bb9631a8e8a5fe1452f01f0bc", null ],
    [ "refFreq", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a3b647a722e160769390ac1967b22b318", null ],
    [ "scl_en", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a4a25b3b2bb75e777055847912374fb98", null ],
    [ "scl_loc", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#aaf38935d579a0f7d53c452aa4988e72a", null ],
    [ "sda_en", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a2257ccf4ca80b3a6e4e39f1d659a11cc", null ],
    [ "sda_loc", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#aa8b2b212d46395d626832447eaeb0201", null ]
];